package TourCompany;

public class AbroadTicketsRequest {
    private int ticketRequestCounter;
    private int issuedById;
    private int planeId;
    private int ticketId;

    public AbroadTicketsRequest(int ticketRequestCounter, int issuedById, 
            int planeId, int Id) {
        this.ticketRequestCounter = ticketRequestCounter;
        this.issuedById = issuedById;
        this.planeId = planeId;
        this.ticketId = Id;
    }
    
    public static void countMessages(AbroadTicketsRequest[] email) {
        int maxMessages = 4;
        if (email.length>maxMessages) {
            System.out.println("Too many messages have been sent."
                    + " Maximum messages queue: "+maxMessages);
        }
    }
    
    public int getTicketRequestCounter() {
        return ticketRequestCounter;
    }
    public int getIssuedById() {
        return issuedById;
    }

    public int getPlaneId() {
        return planeId;
    }
    public int getID() {
        return ticketId;
    }   
}
