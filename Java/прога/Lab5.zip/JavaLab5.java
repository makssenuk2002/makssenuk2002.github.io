package TourCompany;

public class JavaLab5 {

    public static void main(String[] args) {
        AbroadTicketsRequest[] AllMessages = { new AbroadTicketsRequest(8, 23, 4, 2),new AbroadTicketsRequest(5, 90, 2, 2)
        ,new AbroadTicketsRequest(4, 50, 2, 364) ,new AbroadTicketsRequest(13, 830, 4, 790) };
        AbroadTicketsRequest.countMessages(AllMessages);
        smallestMessage(AllMessages);
        System.out.println("Smallest message has id:"+smallestMessage(AllMessages));
    }
    
    public static int smallestMessage(AbroadTicketsRequest[] i) {
        int min = 60000;
        int minMessageID = 0;
        for (int k=0; k<i.length; k++) {
            if (min > i[k].getIssuedById() + 
                    i[k].getTicketRequestCounter() + i[k].getPlaneId()) {
                min = i[k].getIssuedById() + 
                    i[k].getTicketRequestCounter() + i[k].getPlaneId();
                minMessageID = k;
            }
        }
    return i[minMessageID].getID();
    }
    
}
