package com.AttractionsMaven;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.GregorianCalendar;
import java.util.Date;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import java.text.SimpleDateFormat;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelLoader {

    public ArrayList<Ticket> loadTickets(String sourceName) {
        ArrayList<Ticket> clientsList = new ArrayList<>();
        try {
            FileInputStream inputStream = 
                    new FileInputStream(new File(sourceName));
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet firstSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = firstSheet.iterator();
            
            SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
            
            while (iterator.hasNext()) {
                Row line = iterator.next();
                Iterator<Cell> cellIterator = line.cellIterator();
                
                Cell cell = cellIterator.next();
                String secondName = cell.getRichStringCellValue().getString();
                
                cell = cellIterator.next();
                Ticket.AttractionType type = 
                Ticket.AttractionType.valueOf
                (cell.getRichStringCellValue().getString());
                
                cell = cellIterator.next();
                int cost = (int) cell.getNumericCellValue();
                
                cell = cellIterator.next();
                Date date = cell.getDateCellValue();
                System.out.println("Loded successfully");
                GregorianCalendar calendar = new GregorianCalendar();
                calendar.setTime(date);
                calendar.add(calendar.MONTH, 1);
                clientsList.add(new Ticket(secondName, type, cost, 
                                                                calendar));
            }

            workbook.close();
            inputStream.close();
    
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return clientsList;
    }

    public void saveTickets(String sourceName, List<Ticket> client) {
        try {
            FileOutputStream saver = new FileOutputStream(sourceName);
            Workbook workbook = new XSSFWorkbook();
            Sheet listok = workbook.createSheet("Tickets");
            
            CreationHelper createHelper = workbook.getCreationHelper();
            CellStyle dateCellStyle = workbook.createCellStyle();
            dateCellStyle.setDataFormat(createHelper.createDataFormat().
                                        getFormat("dd.MM.yyyy"));
            
            int i = 0;
            for (Ticket ticket: client) {
                Row stroka = listok.createRow(i);
                Cell cell = stroka.createCell(0);
                cell.setCellValue(ticket.getSecondName());
                
                cell = stroka.createCell(1);
                cell.setCellValue(ticket.getCategory().toString());
                
                cell = stroka.createCell(2);
                cell.setCellValue((double)ticket.getCost());
                
                cell = stroka.createCell(3);
                cell.setCellValue(ticket.getCalendar());
                cell.setCellStyle(dateCellStyle);
                i++;
            }
            workbook.write(saver);
            saver.close();
        }
        catch(Exception e) {
            
        }
    }
    
}