package javalr6;

public enum Sex {
    MAN, WOMAN
}
