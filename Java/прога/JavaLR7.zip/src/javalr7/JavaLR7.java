package javalr7;

public class JavaLR7 {
    public static void main(String[] args) {
        
        Workman[] workmen = new Workman[3];
        workmen[0] = new WorkmanWithSalary(500000, 1500000, 15000, 52, "Jason Statham");
        workmen[1] = new WorkmanWithSalary(600000, 1500000, 16000, 55, "Keanu Reeves");
        workmen[2] = new WorkmanForHour(1200000, 20, 56, "Jonny Depp");
        
                double salary = 0;
        for (Workman workman : workmen) {
            workman.Report();
            System.out.println("Name: " + workman.getName() + "," + " Salary: "
                    + workman.getSalary());
            salary += workman.getSalary();
        }
        System.out.println("Total salary: " + salary);
    }
}
        
        

