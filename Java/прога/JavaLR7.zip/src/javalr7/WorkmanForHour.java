package javalr7;

public class WorkmanForHour extends Workman {
    private double fame;
    private int hour;

    public WorkmanForHour(double fame, int hour, int age, String name) {
        super(age, name);
        this.fame = fame;
        this.hour = hour;
    }

    @Override
    public void Report() {
        salary = fame * hour;
    }

    public double getFame() {
        return fame;
    }

    public void setFame(double fame) {
        this.fame = fame;
    }

    public double getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }
}
