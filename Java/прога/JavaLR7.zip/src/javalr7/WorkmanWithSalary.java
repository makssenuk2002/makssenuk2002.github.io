package javalr7;

class WorkmanWithSalary extends Workman {
    private double salaryForWork;
    private int views;
    private double copyright;

    public WorkmanWithSalary(double salaryForWork, int views, double copyright, 
            int age, String name) {
        super(age, name);
        this.salaryForWork = salaryForWork;
        this.views = views;
        this.copyright = copyright;
    }

    public double getSalaryForWork() {
        return salaryForWork;
    }

    public void setSalaryForWork(double salaryForWork) {
        this.salaryForWork = salaryForWork;
    }

    public double getViews() {
        return views;
    }

    public void setViews(int views) {
        this.views = views;
    }

    public double getCopyright() {
        return copyright;
    }

    public void setCopyright(double copyright) {
        this.copyright = copyright;
    }

    @Override
    public void Report() {
        salary = salaryForWork * views * copyright;
    }
}

