package library;

public class Journal extends Document {

    public Journal(String title, String author) {
        super(title, author);
    }

    @Override
    public void printInfo() {
        System.out.println("Type: Journal, Title of article: " + title + "," + " Author: " + author);
    }
}
