package library;

public class Book extends Document {

    public Book(String title, String author) {
        super(title, author);
    }

    @Override
    public void printInfo() {
        System.out.println("Type: Book, Title: " + title + "," + " Author: " + author);
    }
}
