package library;

public class JavaLR7Library {
    public static void main(String[] args) {

        Document[] publications = new Document[4];
        publications[0] = new Book("Kobzar", "Taras Shevchenko");
        publications[1] = new Book("How to win friends", "Dale Karnegie");
        publications[2] = new Journal("Types of planes", "NAU");
        publications[3] = new Book("Mechanics", "KPI");

        for (Document publication : publications) {
            publication.printInfo();
        }
    }
}
