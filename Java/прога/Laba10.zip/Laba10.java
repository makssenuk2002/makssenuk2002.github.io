package RGR;
import java.util.*;

public class Laba10 {
    public static void printListName(ArrayList<Ticket> list) {
        for(Ticket p : list) {
            System.out.println(p.getSecondName());
        }
    }
    
    public static void printListCategory(ArrayList<Ticket> list) {
        for(Ticket p : list) {
            System.out.println(p.getCategory() + " " + p.getSecondName() 
                    + " " + p.getCost() + " " + p.getDate());
        }
    } 
    
    public static void editPolis(Ticket p) {
        try {
            Scanner commandString = new Scanner(System.in);
            System.out.print("Type second name: ");
            String secondName = commandString.nextLine();
                    
            System.out.print("Name attraction type: ");
            Ticket.AttractionType category = 
                Ticket.AttractionType.valueOf(commandString.nextLine());
                    
            System.out.print("Enter ticket cost: ");
            int cost = commandString.nextInt();
                    
            int day, month, year;
            System.out.print("Type the date (day): ");
            day = commandString.nextInt();
            System.out.print("Type the date (month): ");
            month = commandString.nextInt();
            System.out.print("Type the date (year): ");
            year = commandString.nextInt();
            p.setSecondName(secondName);
            p.setCategory(category);
            p.setCost(cost);
            p.setDate(day, month, year);
        }
        catch (Exception e) {
            System.out.println("Please \"AddNewTicket\""
                    + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        ArrayList<Ticket> client = new ArrayList<Ticket>();
        client.add(new Ticket("Ivanenko", Ticket.AttractionType.TRAMPOLINE, 
        100, new GregorianCalendar(2019, 3, 12)));
        client.add(new Ticket("Poroshenko", Ticket.AttractionType.SHOOTING_GALLERY, 
        200, new GregorianCalendar(2019, 4, 17)));
        client.add(new Ticket("Zelenskiy", 
                Ticket.AttractionType.FERRIS_WHEEL, 
        500, new GregorianCalendar(2019, 2, 14)));
        client.add(new Ticket("Kuchma", 
                Ticket.AttractionType.CARS, 
        100, new GregorianCalendar(2019, 2, 15)));
        client.add(new Ticket("Petlura", 
                Ticket.AttractionType.FERRIS_WHEEL, 
        0, new GregorianCalendar(2019, 4, 6)));
              
        System.out.println("Type in \"Help\" to display the command list");
        
        String command = "";
        Scanner commandString = new Scanner(System.in);
        do {
            command = commandString.nextLine();
            switch(command) {
                case "PrintNames":
                    printListName(client);   
                    System.out.println();
                    break;
                case "SortByName":
                    client.sort(Ticket.sortingByName);
                    break;
                case "PrintTicketInfo":
                    printListCategory(client);
                    System.out.println();
                    break;
                case "SortByCategory":
                    client.sort(Ticket.sortingByCategory);
                    System.out.println();
                    break;
                case "SearchByDate":
                    int clientsFound = 0;
                    
                    System.out.print("Type your date: ");
                    
                    command = commandString.nextLine();
                    for(Ticket p : client) {
                        if (p.getDate().equals(command)) {
                            System.out.println(p.getCategory() + " " 
                                    + p.getSecondName() + " " + p.getCost() 
                                    + " " + p.getDate());
                            clientsFound++;
                        }
                    }
                    if (clientsFound == 0) {
                        System.out.println("No tickets found");
                    }
                    break;
                case "AddNewTicket":
                    Ticket addPolis = new Ticket();
                    editPolis(addPolis);
                    client.add(addPolis);
                    System.out.print ("Successfully added to list!");
                    break;
                case "EditTickets":
                    System.out.print("Input second name");
                    String secondName = commandString.nextLine();
                    for(Ticket p : client) {
                        if (p.getSecondName().equals(secondName)) {
                            editPolis(p);
                            break;
                        }
                    }
                    break;
                case "DeleteTicket":
                    System.out.print("");
                    String secondNameForDeleting = commandString.nextLine();
                    for(Ticket p : client) {
                        if (p.getSecondName().equals(secondNameForDeleting)) {
                            client.remove(p);
                            break;
                        }
                    }
                    break;
                case "Help":
                    System.out.println("\"PrintNames\" - list of clients ");
                    System.out.println("\"PrintTicketInfo\" - prints list of tickets ");
                    System.out.println("\"SearchByDate\" - searches all tickets"
                            + "by the given date");
                    System.out.println("\"AddNewTicket\" - Adds new ticket to "
                            + "the list");
                    System.out.println("\"EditTickets\" - Edits tickets by "
                            + "given name");
                    System.out.println("\"DeleteTicket\" - Deletes the ticket "
                            + "by given name");
                    System.out.println("\"Exit\" - exit program.");
                    System.out.println("\"SortByCategory\" - Sort tickets by "
                            + "categoty");
                    System.out.println("\"SortByName\" - Sort tickets by "
                            + "name");
                    break;
            }
        }
        while(!command.equals("Exit"));
    }
}
