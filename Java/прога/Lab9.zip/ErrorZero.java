package laba9;
import java.lang.NumberFormatException;

public class ErrorZero {
    
    public static void main(String[] args) {
        int k=213054/0;
    }
}