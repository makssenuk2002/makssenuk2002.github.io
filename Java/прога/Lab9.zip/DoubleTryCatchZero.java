package laba9;
import java.lang.ArithmeticException;

public class DoubleTryCatchZero {
    public static void main(String[] args) {
                     try {
                     int[] arr = new int[5];
                     System.out.println(arr[6]);
                     int k=1/0;
        }
        catch (ArithmeticException m) {
            System.out.println("Division by zero");
        }
        catch (Exception k) {
            System.out.println("Out of array"+k.getMessage());
            k.printStackTrace();
        }
    }
}
