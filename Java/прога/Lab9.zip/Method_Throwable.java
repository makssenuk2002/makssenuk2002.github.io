package laba9;
import java.lang.ArithmeticException;

public class Method_Throwable {
    public static void main(String[] args) {
        try {
            division(1,0);
        }
        catch (ArithmeticException r) {
            System.out.println(r.getMessage());
        }
    }
    public static int division(int c, int d) throws ArithmeticException {
        return c/d;
    }
    
}
