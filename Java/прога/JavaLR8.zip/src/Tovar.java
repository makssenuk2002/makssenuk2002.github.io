public class Tovar{
    private String name;
    private int cost;

    public Tovar(int cost, String name) {
        this.cost = cost;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }

}
