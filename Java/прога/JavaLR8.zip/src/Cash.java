import java.util.Scanner;

public class Cash implements Functions {
    String password;
    Tovar[] Spisok;
    
    public void login(){
        String l;
        Scanner login = new Scanner(System.in);
        l = login.nextLine();
        
        if (l.equals(password)) {
            System.out.println("Login successful.");
        }
        else {
            System.out.println("Login denied.");
            System.exit(0);
        }
    }
    
    public void printChek() {
        for (int i = 0; i < Spisok.length; i++) {
            System.out.println(Spisok[i].getName()+" "+Spisok[i].getCost());
        }
        System.out.println("Kilkist tovaru: "+Spisok.length);
    }
    
    public void printZvit() {
        int suma = 0;
        for (int i = 0; i < 3; i++) {
            suma += Spisok[i].getCost();
        }
        System.out.println ("Suma zarobitku: "+suma);
        
    }

    public Cash(Tovar[] Spisok, String password) {
        this.Spisok = Spisok;
        this.password = password;
    }
    
    public static void main (String[] args){
        Cash phones = new Cash(new Tovar[] {
            new Tovar(6000, "Samsung"), new Tovar(5000, "LG"), 
            new Tovar(7000, "Lenovo")
        }, "Pazhiloy Iphone");
        Cash cars = new Cash(new Tovar[] {
            new Tovar(30000, "Audi"), new Tovar(40000, "Lamborgini"), 
            new Tovar(20000, "BMW")
        }, "Pazhiloy avtomobil");
        
        phones.login();
        phones.printChek();
        phones.printZvit();
        
        cars.login();
        cars.printChek();
        cars.printZvit();
    }
}
