public interface Functions {
    void login();
    void printChek();
    void printZvit();
}
