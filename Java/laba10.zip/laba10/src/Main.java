public class Main {
    public static void main(String[] args) {
        Tickets kassa = new Tickets();
        kassa.generationTickets();
        kassa.devision();
        kassa.addNewTicket("Didenko", Ticket.typeOfAttraction.BOATS,
                32, "15.05.2021");

        kassa.addNewTicket("Panku", Ticket.typeOfAttraction.BOATS, 32,
                "15.05.2021");
        kassa.sortTicketsByLastName();
        kassa.devision();
        kassa.editTickets(4, "Gnatenko", Ticket.typeOfAttraction.CARS,
                45, "24.04.2021");
        kassa.devision();
        kassa.sortTicketsByType();
        kassa.devision();
        kassa.deleteTickets(4);
        kassa.devision();
        kassa.printAllTickets();
        kassa.devision();
        kassa.printTicketAttraction(Ticket.typeOfAttraction.BOATS);
        kassa.devision();

    }
}